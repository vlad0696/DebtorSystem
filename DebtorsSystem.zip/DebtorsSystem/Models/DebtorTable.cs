﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DebtorsSystem.Models
{
    public class DebtorTable
    {
        public int Year;
        public List<Debtor> debtors;
        public string AllRefund;
        public string AllRefundResidue;

    }
}
